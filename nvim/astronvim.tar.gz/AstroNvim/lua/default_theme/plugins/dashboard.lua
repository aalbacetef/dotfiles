return {
  DashboardHeader = { fg = C.cyan },
  DashboardShortcut = { fg = C.yellow },
  DashboardFooter = { fg = C.cyan },
  DashboardCenter = { fg = C.blue },
}

return {
  GitSignsAdd = { fg = C.green, bg = C.none },
  GitSignsChange = { fg = C.orange_1, bg = C.none },
  GitSignsDelete = { fg = C.red_1, bg = C.none },
  MoreMsg = { fg = C.green, bold = true },
  ModeMsg = { fg = C.grey, bold = true },
}

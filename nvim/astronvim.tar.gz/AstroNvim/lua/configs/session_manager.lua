require("session_manager").setup(astronvim.user_plugin_opts "plugins.session_manager")

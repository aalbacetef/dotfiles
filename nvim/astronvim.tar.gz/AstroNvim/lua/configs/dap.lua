local dap = require "dap"
dap.adapters = astronvim.user_plugin_opts("dap.adapters", dap.adapters)
dap.configurations = astronvim.user_plugin_opts("dap.configurations", dap.configurations)

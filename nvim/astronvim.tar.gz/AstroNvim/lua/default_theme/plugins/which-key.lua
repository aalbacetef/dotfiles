return {
  WhichKeyFloat = { fg = C.fg },
  WhichKeyDesc = { fg = C.blue },
  WhichKeyGroup = { fg = C.blue },
}

require("colorizer").setup(
  astronvim.user_plugin_opts("plugins.colorizer", { user_default_options = { names = false } })
)

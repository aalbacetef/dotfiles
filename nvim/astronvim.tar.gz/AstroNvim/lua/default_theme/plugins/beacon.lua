return { Beacon = { bg = C.blue } }

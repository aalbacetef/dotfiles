require("better_escape").setup(astronvim.user_plugin_opts "plugins.better_escape")
